<?php
    require '_database/database.php';
    @$user_username=$_SESSION['user_username'];
?>