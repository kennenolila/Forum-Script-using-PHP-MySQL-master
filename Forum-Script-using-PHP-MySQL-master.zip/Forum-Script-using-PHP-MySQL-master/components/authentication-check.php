<?php
    header( "refresh:1;url=../login.php" ); 
    echo "<center><h2>Wrong Username or Password (Your email id is you username). Redirecting shortly!</h2></center>";
?>