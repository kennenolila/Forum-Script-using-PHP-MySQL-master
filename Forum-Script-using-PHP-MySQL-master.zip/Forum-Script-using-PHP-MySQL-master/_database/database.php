<?php
	session_start();
    $hostname = "localhost";
    $user = "root";
    $password = "root";
    $database = "forum1";
    $prefix = "";
    $database=mysqli_connect($hostname,$user,$password,$database);
?>