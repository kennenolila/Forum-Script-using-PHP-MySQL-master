<?php include 'components/session-check-index.php' ?>
<?php include 'controllers/base/head.php' ?>
<body style="background-image: url(slider/slide1.jpeg); background-size: cover;">	
    <script type="text/javascript"> 
        ChangeIt();
    </script>
<?php include 'controllers/navigation/index-before-login-navigation.php' ?>
    <section id="home" name="home"></section>
        <div id="headerwrap">
            <div class="container">
                <div class="row centered">
                    <div class="col-lg-12">
                    </div>
                    <div class="row">
                    <div class="col-lg-12">
                        <h1><b>Laverdad Forum</b></h1>
                        <h3>Join Us Laverdarian !</h3>
                        <br>
                    </div>
                </div>
                <div class="col-lg-4">
                </div>
                <div class="col-lg-2">
                    <br>
                </div>
            </div>
        </div> <!--/ .container -->
    </div><!--/ #headerwrap -->
</body>    