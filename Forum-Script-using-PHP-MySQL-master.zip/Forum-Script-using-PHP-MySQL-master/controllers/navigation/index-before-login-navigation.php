    <!-- Before Login Navigation -->
	    <div id="navigation" class="navbar navbar-default navbar-fixed-top">
	      <div class="container">
	        <div class="navbar-header">
	          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	          </button>
                <a class="navbar-brand" href="index.php"><b><i class="fa fa-home"></i> Home</b></a>	        
	        </div>
	        <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav back">
                    <li><a href="forum.php"><i class="fa fa-question-circle"></i> Forum</a></li>
                    <li><a href="notice.php"><i class="fa fa-book"></i> Notice</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="register.php"><i class="fa fa-book"></i> Register</a></li>
                    <li><a href="login.php"><i class="fa fa-plus"></i> Login</a></li>
                </ul> 
	        </div><!--/.nav-collapse -->
	      </div>
	    </div>
    <!-- ./Before Login Navigation -->