        <!-- Navbar2 -->
	    <div id="navigation" class="navbar navbar-default navbar-fixed-top" style="margin-top:50px;">
	      <div class="fluid-container">
	        <div class="navbar-header">
	          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse2">
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	          </button>
                <a class="navbar-brand" href="index.html"><b>W<sub>3</sub>Dzines</b></a>	        
            </div>
	        <div class="navbar-collapse collapse" id="navbar-collapse2">
	          <ul class="nav navbar-nav">
	            <li class="active"><a href="index.html">Home1</a></li>
	            <li><a href="showcase.html">Showcase</a></li>
	            <li><a href="blog.html">Blog</a></li>
	            <li><a href="contact.html">Contact</a></li>
	          </ul>
	        </div><!--/.nav-collapse -->
	      <!--</div>
	    </div>
      <!-- ./Navbar2 -->